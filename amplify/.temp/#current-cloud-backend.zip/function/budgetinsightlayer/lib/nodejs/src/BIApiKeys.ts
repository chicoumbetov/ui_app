const BIApiKeys = {
  dev: {
    clientId: '45913022',
    clientSecret: 'EuDtfrmKj82rd5Wt3ICk5wlDlMJYuV/Y',
    domain: 'omedom1-sandbox',
  },
  prod: {
    clientId: '_____',
    clientSecret: '_____',
    domain: '-----',
  },
};

export default BIApiKeys;
